# Tudo

- personagens/<nome>/: cada personagem com LEIA-ME próprio (skill, ChatGPT, motor, ficha).
- programa/: o motor em arquivo único (cerebro.pyz, cerebro_android.py) e a skill genérica.
