# Vincent Knox: tudo em um lugar

| Onde usar | O que usar |
|---|---|
| Claude.ai (site ou app) | `vincent-knox-skill.zip`: envie em Configurações > Capacidades > Skills e chame com /vincent-knox |
| ChatGPT, GPT personalizado | `gpt/instrucoes.md` no campo Instruções e os arquivos de `gpt/conhecimento/` em Conhecimento |
| ChatGPT ou qualquer chat, sem instalar | cole `gpt/prompt-unico.md` como primeira mensagem |
| Programa em código (chat web, Termux, Pydroid) | `vincent-knox.json` na pasta ~/.cerebro, ou `python cerebro.pyz conversar --arquivo vincent-knox.json` |
| Skill pura em qualquer lugar | `ficha.md` com `/cerebro carregar` |
| Regenerar tudo | `origem.txt` com `python ferramentas/empacotar_personagem.py --nome "Vincent Knox" --origem origem.txt` |

Comandos dentro da conversa: estado, acaso, viver <acontecimento>, salvar, carregar, parar.
