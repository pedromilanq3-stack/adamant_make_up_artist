# Harvey Specter: tudo em um lugar

| Onde usar | O que usar |
|---|---|
| Claude.ai (site ou app) | `harvey-specter-skill.zip`: envie em Configurações > Capacidades > Skills e chame com /harvey-specter |
| ChatGPT, GPT personalizado | `gpt/instrucoes.md` no campo Instruções e os arquivos de `gpt/conhecimento/` em Conhecimento |
| ChatGPT ou qualquer chat, sem instalar | cole `gpt/prompt-unico.md` como primeira mensagem |
| Programa em código (chat web, Termux, Pydroid) | `harvey-specter.json` na pasta ~/.cerebro, ou `python cerebro.pyz conversar --arquivo harvey-specter.json` |
| Skill pura em qualquer lugar | `ficha.md` com `/cerebro carregar` |
| Regenerar tudo | `origem.txt` com `python ferramentas/empacotar_personagem.py --nome "Harvey Specter" --origem origem.txt` |

Comandos dentro da conversa: estado, acaso, viver <acontecimento>, salvar, carregar, parar.
